#include "util/name_id_map.h"

std::string NameIdMap::empty_name;
