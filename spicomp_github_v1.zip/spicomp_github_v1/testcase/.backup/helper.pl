#!/usr/bin/env python3

import io
import itertools


def combination_list(l, rep):
  ls = [list(x) for x in itertools.product(l, repeat=rep)];
  print(ls)

def make_n_by_m_subregions(orig_x, orig_y, len_x, len_y, num_x, num_y):
  for nx in range(num_x):
    for ny in range(num_y):
      l = []
      for lx in range(len_x):
        for ly in range(len_y):
          l.append([orig_x + nx * len_x + lx, orig_y + ny * len_y + ly])
      print(f"      - {l}")


if __name__ == '__main__':
  # combination_list([10, 20], 64)
  make_n_by_m_subregions(0, 0, 2, 2, 2, 2)
